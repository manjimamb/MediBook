import mongoose from "mongoose";

const patientSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, unique: true },
  phone: { type: String, required: true, trim: true, maxlength: 25 }
}, { timestamps: true });

export default mongoose.model("Patient", patientSchema);
