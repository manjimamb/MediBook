import mongoose from "mongoose";

const appointmentSchema = new mongoose.Schema({
  patient: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
  patientName: { type: String, required: true, trim: true },
  patientEmail: { type: String, required: true, trim: true, lowercase: true },
  doctor: { type: String, required: true, trim: true },
  department: { type: String, required: true, trim: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  reason: { type: String, default: "", trim: true, maxlength: 500 },
  status: { type: String, enum: ["Pending", "Confirmed", "Completed", "Cancelled"], default: "Pending" }
}, { timestamps: true });

appointmentSchema.index({ date: 1, time: 1, doctor: 1 });

export default mongoose.model("Appointment", appointmentSchema);
