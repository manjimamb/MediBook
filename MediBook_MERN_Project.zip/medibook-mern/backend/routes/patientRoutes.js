import { Router } from "express";
import Patient from "../models/Patient.js";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const patients = await Patient.find().sort({ createdAt: -1 }).limit(500);
    res.json(patients);
  } catch (error) { next(error); }
});

router.post("/", async (req, res, next) => {
  try {
    const { name, email, phone } = req.body;
    if (!name?.trim() || !email?.trim() || !phone?.trim()) {
      return res.status(400).json({ message: "Name, email, and phone are required." });
    }
    const patient = await Patient.create({ name, email, phone });
    res.status(201).json(patient);
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "This email is already registered." });
    next(error);
  }
});

export default router;
