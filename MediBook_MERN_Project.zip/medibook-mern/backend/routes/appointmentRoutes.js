import { Router } from "express";
import mongoose from "mongoose";
import Appointment from "../models/Appointment.js";
import Patient from "../models/Patient.js";

const router = Router();
const validStatuses = ["Pending", "Confirmed", "Completed", "Cancelled"];

router.get("/", async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.status && validStatuses.includes(req.query.status)) filter.status = req.query.status;
    if (req.query.search) {
      const search = String(req.query.search).trim();
      filter.$or = [
        { patientName: { $regex: search, $options: "i" } },
        { patientEmail: { $regex: search, $options: "i" } },
        { doctor: { $regex: search, $options: "i" } },
        { department: { $regex: search, $options: "i" } }
      ];
    }
    const appointments = await Appointment.find(filter).sort({ date: 1, time: 1 }).limit(1000);
    res.json(appointments);
  } catch (error) { next(error); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid appointment ID." });
    const appointment = await Appointment.findById(req.params.id);
    if (!appointment) return res.status(404).json({ message: "Appointment not found." });
    res.json(appointment);
  } catch (error) { next(error); }
});

router.post("/", async (req, res, next) => {
  try {
    const { patientId, doctor, department, date, time, reason = "" } = req.body;
    if (![patientId, doctor, department, date, time].every(value => String(value || "").trim())) {
      return res.status(400).json({ message: "Patient, doctor, department, date, and time are required." });
    }
    if (!mongoose.isValidObjectId(patientId)) return res.status(400).json({ message: "Invalid patient ID." });
    if (Number.isNaN(Date.parse(date))) return res.status(400).json({ message: "Please provide a valid appointment date." });
    const patient = await Patient.findById(patientId);
    if (!patient) return res.status(404).json({ message: "Patient not found. Register the patient first." });

    const conflict = await Appointment.findOne({ doctor, date, time, status: { $in: ["Pending", "Confirmed"] } });
    if (conflict) return res.status(409).json({ message: "This doctor already has an appointment at that date and time." });

    const appointment = await Appointment.create({
      patient: patient._id, patientName: patient.name, patientEmail: patient.email,
      doctor, department, date, time, reason
    });
    res.status(201).json(appointment);
  } catch (error) { next(error); }
});

router.put("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid appointment ID." });
    const allowed = ["doctor", "department", "date", "time", "reason", "status"];
    const update = {};
    for (const key of allowed) if (req.body[key] !== undefined) update[key] = req.body[key];
    if (update.status && !validStatuses.includes(update.status)) return res.status(400).json({ message: "Invalid appointment status." });
    if (update.date && Number.isNaN(Date.parse(update.date))) return res.status(400).json({ message: "Please provide a valid appointment date." });

    const current = await Appointment.findById(req.params.id);
    if (!current) return res.status(404).json({ message: "Appointment not found." });
    const doctor = update.doctor ?? current.doctor;
    const date = update.date ?? current.date;
    const time = update.time ?? current.time;
    const status = update.status ?? current.status;
    if (["Pending", "Confirmed"].includes(status)) {
      const conflict = await Appointment.findOne({
        _id: { $ne: current._id }, doctor, date, time, status: { $in: ["Pending", "Confirmed"] }
      });
      if (conflict) return res.status(409).json({ message: "This doctor already has an appointment at that date and time." });
    }
    Object.assign(current, update);
    await current.save();
    res.json(current);
  } catch (error) { next(error); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid appointment ID." });
    const deleted = await Appointment.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Appointment not found." });
    res.json({ message: "Appointment deleted successfully." });
  } catch (error) { next(error); }
});

export default router;
